<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\GstPdfTable;


class GstPdfTableController extends Controller
{
    public function index()
    {
        $gstPdfRecords = GstPdfTable::all();
        return view('gst_pdf.index', compact('gstPdfRecords')); // For Web View
    }
    public function create()
    {
        return view('gst_pdf.create'); // For Web View
    }
}
