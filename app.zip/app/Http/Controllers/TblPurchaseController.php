<?php

namespace App\Http\Controllers;

use App\Models\tbl_purchase;
use Illuminate\Http\Request;
use App\Models\tbl_party;
use App\Models\tbl_category;
use App\Models\tbl_sub_category;
use App\Models\tbl_purchase_item;

class TblPurchaseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(tbl_purchase $tbl_purchase)
    {
        $inwards = tbl_purchase::with('party') 
        ->select('date', 'invoice_no', 'amount', 'inr_rate', 'inr_amount', 'shipping_cost', 'pid')  
        ->orderBy('id', 'asc')
        ->get()
        ->map(function($purchase) {
            return [
                'date' => $purchase->date,
                'invoice_no' => $purchase->invoice_no,
                'party_name' => $purchase->party->party_name,
                'amount' => $purchase->amount,
                'inr_rate' => $purchase->inr_rate,
                'inr_amount' => $purchase->inr_amount,
                'shipping_cost' => $purchase->shipping_cost,
            ];
        });
      
        $SubCategories = tbl_sub_category::all();
        $Categories = tbl_category::all();
        $tbl_parties = tbl_party::all();
        
        return view('show_inward', ['inwards'=>$inwards,'Categories'=>$Categories,'tbl_parties'=>$tbl_parties,'SubCategories'=>$SubCategories]);
    
    }

    public function filter(Request $request) {
        // Retrieve form inputs
        $s_date = $request->get('s_date');
        $e_date = $request->get('e_date');
        $invoice_number = $request->get('invoice_number');
        $p_name = $request->get('p_name');
        $amount = $request->get('amount');
        $amount_inr = $request->get('amount_inr');
    
        // Query with filters
        $inwards = tbl_purchase::with('party') 
            ->select('date', 'invoice_no', 'amount', 'inr_rate', 'inr_amount', 'shipping_cost', 'pid')
            ->when($s_date, function($query, $s_date) {
                return $query->where('date', '>=', $s_date);
            })
            ->when($e_date, function($query, $e_date) {
                return $query->where('date', '<=', $e_date);
            })
            ->when($invoice_number, function($query, $invoice_number) {
                return $query->where('invoice_no', 'LIKE', '%' . $invoice_number . '%');
            })
            ->when($p_name, function($query, $p_name) {
                return $query->whereHas('party', function($q) use ($p_name) {
                    $q->where('pid', 'LIKE', '%' . $p_name . '%'); 
                });
            })
            ->when($amount, function($query, $amount) {
                return $query->where('amount', $amount); 
            })
            ->when($amount_inr, function($query, $amount_inr) {
                return $query->where('inr_amount', $amount_inr);
            })
            ->orderBy('id', 'asc')
            ->get()
            ->map(function($purchase) {
                return [
                    'date' => $purchase->date,
                    'invoice_no' => $purchase->invoice_no,
                    'party_name' => $purchase->party->party_name, 
                    'amount' => $purchase->amount,
                    'inr_rate' => $purchase->inr_rate,
                    'inr_amount' => $purchase->inr_amount,
                    'shipping_cost' => $purchase->shipping_cost,
                ];
            });

            $SubCategories = tbl_sub_category::all();
            $Categories = tbl_category::all();
            $tbl_parties = tbl_party::all();
            // dd($tbl_parties);
        return view('show_inward', ['inwards'=>$inwards,'Categories'=>$Categories,'tbl_parties'=>$tbl_parties,'SubCategories'=>$SubCategories]);
    }
    

    public function one_purchase(tbl_purchase $tbl_purchase, $invoice_no){
        $inwards = tbl_purchase::with('party')
        ->where('invoice_no', $invoice_no) 
        ->orderBy('id', 'asc')
        ->get();
        $SubCategories = tbl_sub_category::all();
        $Categories = tbl_category::all();
        $tbl_parties = tbl_party::all();
        // dd("here");
        // dd($inwards);
        // $inwards = tbl_purchase_item::all();
        return view('show_srno', compact('inwards'));
        // return view('show_srno', data: ['inwards'=>$inwards,'Categories'=>$Categories,'tbl_parties'=>$tbl_parties,'SubCategories'=>$SubCategories]);
    
    }

    public function add_sr_no(){
        $inwards = tbl_purchase::with('party')
        ->orderBy('id', 'asc')
        ->get();

        $SubCategories = tbl_sub_category::all();
        $Categories = tbl_category::all();
        $tbl_parties = tbl_party::all();
        return view('add_srno', compact('inwards','tbl_parties','Categories','SubCategories'));
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(tbl_purchase $tbl_purchase)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, tbl_purchase $tbl_purchase)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(tbl_purchase $tbl_purchase)
    {
        //
    }
}
