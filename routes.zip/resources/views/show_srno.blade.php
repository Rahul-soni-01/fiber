
<x-layout>
    <x-slot name="title">Add Sr. No.</x-slot>
        <x-slot name="main">
        <div class="main" id="main">

        </div>
    </x-slot>
</x-layout>
