<x-layout>
    <x-slot name="title">Add Sr. No.</x-slot>
    <x-slot name="main">
        <div class="main" id="main">
            <form action="search" method="get">
                <div class="container">
                    <div class="row g-2 align-items-center">
                        <!-- Purchase Select -->
                        <div class="col-md">
                            <select class="form-control" name="invoice_no" id="invoice_no" onchange="change_purchase()">
                                <option value="" disabled selected>Select Invoice No</option>
                                @foreach($inwards as $tbl_purchase)
                                    <option value="{{ $tbl_purchase->invoice_no }}">{{ $tbl_purchase->invoice_no }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Category Select -->
                        <div class="col-md">
                            <select class="form-control" name="cid" id="category" onchange="change_category()">
                                <option value="" disabled selected class="0">Select Category</option>
                                @foreach($Categories as $category)
                                    <option value="{{ $category->id }}" class="{{ $category->id }}">
                                        {{ $category->category_name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Sub Category Select -->
                        <div class="col-md">
                            <select class="form-control" name="sid" id="subcategory" onchange="change_subcategory()">
                                <option value="" disabled selected class="0">Select Sub Category</option>
                                @foreach($SubCategories as $subcategory)
                                    <option value="{{ $subcategory->id }}" class="{{ $subcategory->id }}">
                                        {{ $subcategory->sub_category_name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Quantity Input -->
                        <div class="col-md">
                            <input type="text" class="form-control" name="qty" id="qty" placeholder="Add Qty"
                                onchange="append_fields()">
                            <input type="checkbox" name="sr_check" id="sr_check" hidden>
                        </div>

                        <!-- Price Input -->
                        <div class="col-md">
                            <input type="text" class="form-control" id="price" name="price" placeholder="Add Price"
                                disabled>
                        </div>

                        <!-- Submit Button -->
                        <div class="col-md">
                            <button type="button" class="btn btn-dark" name="add_stock" id="add_stock">Submit</button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 offset-sm-3 ">
                            <div class="row append_fields"></div>
                            
                        </div>
                    </div>
                </div>

            </form>

        </div>
    </x-slot>
</x-layout>