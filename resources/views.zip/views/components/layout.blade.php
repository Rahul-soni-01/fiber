<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{$title}}</title>
    <link rel="shortcut icon" href="{{asset('storage/favicon.ico') }}">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="{{ asset('js/script.js') }}"></script>
    <script src="js/jquery-3.7.1.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css" rel="stylesheet" />
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
</head>

<body>
<meta name="csrf-token" content="{{ csrf_token() }}">

    <div id="header">
        <label id="menu" class="button bars" for="check"><i class="ri-menu-line"></i></label>
        <div class="logo" style=""><img src="{{asset('storage/logo.jpg') }}" alt=""></div>
    </div>
    <div id="fakeheader"></div>

    <input type="checkbox" id="check" checked hidden>
    <div class="slidebar" id="slidebar">
        <ul>
            <li>
                <a href="home"><i class="ri-home-2-line"></i>Home</a>
            </li>
            <li>
                <a class="sub-btn-add" id="sub-btn-add"><i class="ri-add-line"></i>Add <i
                        class="ri-arrow-down-s-line"></i></a>
                <ul class="sub-menu" id="sub-menu">
                    <li><a href="add_party" class="sub-item">Add Party</a></li>
                    <li><a href="add_category" class="sub-item">Add Category</a></li>
                    <li><a href="add_report" class="sub-item">Add Report</a></li>
                    <li><a href="{{ route('add_sr_no') }}" class="sub-item">Add Sr No.</a></li>
                </ul>
            </li>
            <li>
                <a class="sub-btn-show" id="sub-btn-show"><i class="ri-eye-line"></i>Show<i
                        class="ri-arrow-down-s-line"></i></a>
                <ul class="sub-menu" id="sub-menu">
                    <li><a href="party" class="sub-item">Show Party</a></li>
                    <li><a href="category" class="sub-item">Show Category</a></li>
                </ul>
            </li>
            <li>
                <a class="sub-btn-purchase" id="sub-btn-purchase"><i class="ri-shopping-cart-2-line"></i>Purchase <i
                        class="ri-arrow-down-s-line"></i></a>
                <ul class="sub-menu" id="sub-menu">
                    <li><a href="good_inward" class="sub-item">Good Inwards</a></li>
                    <li><a href="inward" class="sub-item">Show Inward</a></li>
                    <li><a href="#" class="sub-item">Good Inwards</a></li>
                    <li><a href="#" class="sub-item">Good Inwards</a></li>
                </ul>
            </li>
            <li>
                <a href="/logout"><i class="ri-logout-box-r-line"></i>Log out</a>
            </li>

        </ul>
    </div>
    <div class="main" id="main" style="margin-left:190px;">
        <h3>{{$title}}</h3>
        <hr style="border:0.5px solid lightgray;">
        {{$main}}
    </div>
    <!-- <div class="footer" id="footer">
        <h1>Footer Page</h1>
    </div> -->

    <script type="text/javascript">
        $(document).ready(function () {

            $('#check').on('change', function () {
                if (this.checked) {
                    // document.getElementById("title").style.marginLeft = "190px";
                    document.getElementById("main").style.marginLeft = "190px";
                    document.getElementById("footer").style.marginLeft = "190px";
                }
                else {
                    // document.getElementById("title").style.marginLeft = "0px";
                    document.getElementById("main").style.marginLeft = "0px";
                    document.getElementById("footer").style.marginLeft = "0px";
                };
            });

            $("#sub-btn-add").on("click", function (e) {
                $(this).next('#sub-menu').slideToggle();
            });

            $("#sub-btn-show").on("click", function (e) {
                $(this).next('#sub-menu').slideToggle();
            });

            $("#sub-btn-purchase").on("click", function (e) {
                $(this).next('#sub-menu').slideToggle();
            });


        });

        var count = 1;
        function BtnAdd(categories, subCategories) {

            $('#TBody').append(`
                <div class="container">
                <div class="row" id="row_${count}" style="margin-top:10px;">
                        <div class="col-sm-2">
                          
                            <select id="data[${count}][cname]" name="data[${count}][cname]" class="form-control">
                             
                                <option value="" disabled selected>Choose a Category</option>
                                
                            </select>
                        </div>
                        <div class="col-sm-2">
                          
                            <select id="data[${count}][scname]" name="data[${count}][scname]" class="form-control">
                                <option value="" disabled selected>Choose a Sub Category</option>
                            </select>
                        </div>
                        <div class="col-sm-1">
                           
                            <select id="data[${count}][unit]" name="data[${count}][unit]"
                                class="form-control">
                                <option value="">Select</option>
                                <option value="Pic">Pic</option>
                                <option value="Mtr">Mtr</option>
                            </select>
                        </div>
                        <div class="col-sm-1">
                           
                            <input type="number" id="data[${count}][qty]" name="data[${count}][qty]"
                                class="form-control" onchange="total()">
                        </div>
                        <div class="col-sm-1">
                            
                            <input type="number" id="data[${count}][rate]" name="data[${count}][rate]"
                                class="form-control" onchange="total()">
                        </div>
                        <div class="col-sm-1">
                          
                            <input type="number" id="data[${count}][p_tax]" name="data[${count}][p_tax]" step="0.01" class="form-control" onchange="total()">
                        </div>
                        <div class="col-sm-1">
                            
                            <input type="number" id="data[${count}][tax]" step="0.01" name="data[${count}][tax]"
                                class="form-control" disabled>
                        </div>
                        <div class="col-sm-2">
                            
                            <input type="number" id="data[${count}][total]" name="data[${count}][total]"
                            step="0.01" class="form-control">
                        </div>
                        <div class="col-sm-1"><button type="button" class="btn btn-grey" onclick="BtnDel(this)">Delete</button></div>
                    </div>
                </div>
            `);

            // Append categories
            if (categories && Array.isArray(categories)) {
                categories.forEach(category => {
                    $(`#data\\[${count}\\]\\[cname\\]`).append(`
                <option value="${category.id}">${category.category_name}</option>
            `);
                });
            }

            // Append subcategories
            if (subCategories && Array.isArray(subCategories)) {
                subCategories.forEach(subCategory => {
                    $(`#data\\[${count}\\]\\[scname\\]`).append(`
                <option value="${subCategory.id}">${subCategory.sub_category_name}</option>
            `);
                });
            }

            count++;
        }
        function BtnDel(button) {
            $(button).closest('.row').remove();
            count--;
            total();
        }

        function total() {
            for (var i = 0; i < count; i++) {
                var qty = parseFloat(document.getElementById(`data[${i}][qty]`).value) || 0;
                var rate = parseFloat(document.getElementById(`data[${i}][rate]`).value) || 0;
                var p_tax = parseFloat(document.getElementById(`data[${i}][p_tax]`).value) || 0;

                var total = qty * rate;
                var taxAmount = (total * p_tax) / 100;
                total += taxAmount;

                document.getElementById(`data[${i}][tax]`).value = taxAmount.toFixed(2);
                document.getElementById(`data[${i}][total]`).value = total.toFixed(2);
            }
            sub_total();
        }

        function rate() {
            var amount1 = parseFloat(document.getElementById(`amount_d`).value) || 0;
            var rate1 = parseFloat(document.getElementById(`rate_r`).value) || 0;

            var amount = amount1 * rate1;

            document.getElementById(`sub_total`).value = amount.toFixed(2);
            document.getElementById(`amount_r`).value = amount.toFixed(2);
            document.getElementById(`amount`).value = amount.toFixed(2);
        }
        function calculateshipping() {
            var amount = parseFloat(document.getElementById(`amount_r`).value) || 0;
            var shipping_cost = parseFloat(document.getElementById(`shipping_cost`).value) || 0;

            var total = shipping_cost +amount;
            document.getElementById(`sub_total`).value = total.toFixed(2);
            document.getElementById(`amount`).value = total.toFixed(2);

        }

        function sub_total() {
            var subtotal = 0;
            for (var i = 0; i < count; i++) {
                var total = parseFloat(document.getElementById(`data[${i}][total]`).value) || 0;
                subtotal += total;
            }
            document.getElementById("sub_total").value = subtotal.toFixed(2);
            document.getElementById("amount_r").value = subtotal.toFixed(2);
            document.getElementById("amount_d").value = subtotal.toFixed(2);
            calculateAmount();
        }

        function calculateAmount() {
            var subtotal = parseFloat(document.getElementById("sub_total").value) || 0;
            var roundAmount = parseFloat(document.getElementById("round_total").value) || 0;
            var amount = subtotal - roundAmount;
            document.getElementById("amount").value = amount.toFixed(2);
        }

        function AddRow() {
            var row = 1;
            $('#TBody').append(`
                <tr>
                    <td>
                        <h5>LED
                            <select required>
                                <option value="">Select</option>
                                <option value="12">12</option>
                                <option value="15">15</option>
                                <option value="30">30</option>
                                <option value="45">45</option>
                            </select>
                        </h5>
                    </td>
                    <td><input type="text" id="srled_${row}" name="srled_${row}"></td>
                    <td><input type="text" id="ampled_${row}" name="ampled_${row}"></td>
                    <td><input type="text" id="voltled_${row}" name="voltled_${row}"></td>
                    <td><input type="text" id="wattled_${row}" name="wattled_${row}">
                        <button onclick="addRow()" style="height: 25px;width: 40px;float: right;margin-left: -40px;">Add</i></button>
                    </td>
                </tr>
            `);
            row++;
        }

    </script>
</body>

</html>