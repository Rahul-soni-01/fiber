<x-layout>
    <x-slot name="title">Add Category</x-slot>
    <x-slot name="main">
        <div class="container my-4" id="main1">
            <!-- Form to Add Category -->
            <form action="addcategory" method="post">
                @csrf
                <div class="row mb-3">
                    <div class="col-md-3">
                        <h3>Category</h3>
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="category_name" id="category_name" placeholder="Enter category name" required>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-dark">Submit</button>
                    </div>
                </div>
            </form>
            <hr class="my-4">

            <!-- Form to Add Sub Category -->
            <form action="addsubcategory" method="post">
                @csrf
                <h3>Add Sub Category</h3>
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="category" class="form-label">Category</label>
                        <select name="category" id="category"  class="form-control" required>
                            <option value="">Select Category</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->category_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="sub_category" class="form-label">Sub Category</label>
                        <input type="text" name="sub_category" id="sub_category" class="form-control" placeholder="Enter sub category" required>
                    </div>
                    <div class="col-md-3">
                        <label for="unit" class="form-label">Unit</label>
                        <select name="unit" id="unit"  class="form-control" required>
                            <option value="">Select Unit</option>
                            <option value="Pic">Pic</option>
                            <option value="Mtr">Mtr</option>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="sr_no" class="form-label">SR No.</label><br>
                            <input type="hidden" name="sr_no" value="0">
                            <input type="checkbox" id="sr_no" name="sr_no" value="1" >
                        </div>
                        <div class="col-md-3 mt-3">
                            <button type="submit" class="btn btn-dark">Submit</button>
                        </div>
                    </div>  
                </div>
            </form>
        </div>
    </x-slot>
</x-layout>
