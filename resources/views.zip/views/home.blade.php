<x-layout>
    <x-slot name="title">Home Page</x-slot>
    <x-slot name="main">
        <div>
            <h1>Home Page</h1>
            <h1>Sub Heading</h1>
            <h1>Dummy Paragraph</h1>
        </div>
    </x-slot>
</x-layout>